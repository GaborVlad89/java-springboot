SELECT * FROM user;
INSERT INTO user (role,id,name,password,username) VALUES ('ADMIN',1, 'vlad', 'vlad1', 'vlad@admin');

SELECT * FROM user;
SELECT * FROM menuitem;
SELECT * FROM orderitems;

DELETE FROM user;
